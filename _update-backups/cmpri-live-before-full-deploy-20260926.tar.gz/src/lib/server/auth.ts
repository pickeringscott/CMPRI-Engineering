import "server-only";
import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import type { NextRequest } from "next/server";
import { HOTEL_ID } from "@/lib/constants";
import { SUPABASE_PUBLISHABLE_KEY, SUPABASE_URL } from "@/lib/supabase/config";
import { allows, type AccessProfile, type Capability, type Membership, type Permission } from "./access";
import { createSupabaseAdmin } from "./supabase-admin";

const authOptions = {
  auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
};

function createBearerClient(token: string): SupabaseClient {
  return createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
    ...authOptions,
    global: { headers: { Authorization: `Bearer ${token}` } },
  });
}

function extractBearer(header: string | null): string | null {
  const match = header?.match(/^Bearer\s+([^\s]+)$/i);
  return match ? match[1] : null;
}

export type AuthAttempt =
  | { ok: true; principal: import("./access").Principal; admin: SupabaseClient }
  | { ok: false; reason: "no-bearer" | "verify-failed" | "email-mismatch" | "profile-missing" | "profile-inactive" | "membership-missing" | "membership-inactive" | "membership-error" | "profile-error" | "permission-error" | "exception"; detail?: string };

async function attemptAuth(request: NextRequest): Promise<AuthAttempt> {
  const bearer = extractBearer(request.headers.get("authorization"));
  if (!bearer) return { ok: false, reason: "no-bearer" };

  const verifier = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, authOptions);
  const sessionClient = createBearerClient(bearer);
  const admin = createSupabaseAdmin();
  const lookup = admin ?? sessionClient;

  try {
    const { data: userData, error: verifyError } = await verifier.auth.getUser(bearer);
    if (verifyError || !userData.user) {
      return { ok: false, reason: "verify-failed", detail: verifyError?.message };
    }
    const userId = userData.user.id;
    const email = userData.user.email ?? null;

    const { data: profileRow, error: profileError } = await lookup
      .from("profiles")
      .select("id, email, full_name, role, active, property_scope")
      .eq("id", userId)
      .maybeSingle();
    if (profileError) return { ok: false, reason: "profile-error", detail: profileError.message };
    if (!profileRow) return { ok: false, reason: "profile-missing" };
    const profile = profileRow as AccessProfile;
    if (!email || !profile.email || email.trim().toLowerCase() !== profile.email.trim().toLowerCase()) {
      return { ok: false, reason: "email-mismatch" };
    }
    if (profile.active !== true) return { ok: false, reason: "profile-inactive" };

    const { data: memberRow, error: memberError } = await lookup
      .from("hotel_members")
      .select("user_id, hotel_id, role, active")
      .eq("user_id", userId)
      .eq("hotel_id", HOTEL_ID)
      .maybeSingle();
    if (memberError) return { ok: false, reason: "membership-error", detail: memberError.message };
    if (!memberRow) return { ok: false, reason: "membership-missing" };
    const membership = memberRow as Membership;
    if (membership.active !== true) return { ok: false, reason: "membership-inactive" };

    const { data: permissionRows, error: permissionError } = await lookup
      .from("role_permissions")
      .select("role, permission, allowed");
    if (permissionError) return { ok: false, reason: "permission-error", detail: permissionError.message };

    const principal = {
      identity: { id: userId, email },
      profile,
      hotelId: HOTEL_ID,
      membership,
      permissions: (permissionRows ?? []) as Permission[],
    };
    return { ok: true, principal, admin: admin ?? sessionClient };
  } catch (error) {
    return { ok: false, reason: "exception", detail: error instanceof Error ? error.message : String(error) };
  }
}

export async function requireUserAttempt(request: NextRequest): Promise<AuthAttempt> {
  return attemptAuth(request);
}

export async function requireUser(request: NextRequest) {
  const result = await attemptAuth(request);
  return result.ok ? { principal: result.principal, admin: result.admin } : null;
}

export async function requireCapability(request: NextRequest, capability: Capability) {
  const auth = await requireUser(request);
  if (!auth || !allows(auth.principal, capability)) return null;
  return auth;
}
